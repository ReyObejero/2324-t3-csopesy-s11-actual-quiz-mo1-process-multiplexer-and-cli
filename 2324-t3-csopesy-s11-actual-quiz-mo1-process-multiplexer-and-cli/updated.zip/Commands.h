#pragma once
#include <string>
#include "ConsoleManager.h"

// Function prototypes
void displayHeader();
void clearScreen();
// bool handleCommand(const std::string& command, ConsoleManager& consoleManager);
